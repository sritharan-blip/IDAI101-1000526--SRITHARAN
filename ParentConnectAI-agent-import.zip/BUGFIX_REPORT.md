# ParentConnect AI — Bug Fix Report

## The bug you hit, explained

You asked: **"How many days was Adrian of grade 11 present this month"**
It replied: **"Adrian of grade 8 has an attendance percent of 92%"**

Adrian was right. Grade 11 became Grade 8. Here's exactly why.

### Cause 1 — a "remember the last child" feature that silently misfired

`AttendanceIntent` (and 17 other intents) were built to "remember" the
grade/child you last asked about, using a Dialogflow context called
`parent_session`. The rule was: *if this message doesn't clearly state a
grade, quietly reuse whatever grade was mentioned earlier in the chat.*

The problem: Dialogflow didn't fail to see "grade 11" because you didn't
say it — it failed because there was only **one** training example in the
whole agent shaped like "How many days was X of grade Y present this
month", and it happened to hard-code "Grade 8" in it. One example isn't
enough for Dialogflow's model to reliably learn "the grade can be anything
here" — so on a slightly different name/grade, it sometimes didn't
recognize "grade 11" as a grade at all in that sentence shape. When that
happens, Dialogflow doesn't say "I don't know" — it fell back to the
"remembered" value from earlier in the conversation instead. That's the
"old stored content" you noticed. It's not that the bot is dumb — it's that
guessing-from-memory was silently allowed to override what you'd just
said, with zero visible sign it had happened.

**Fix:** I removed that silent fallback everywhere (18 intents, 25
parameters). Now, if a message doesn't clearly include the grade or
child's name, the bot **asks you directly** instead of guessing from
memory — "Which grade or child would you like the attendance for?" That's
also just what a real support agent does: confirm, don't assume.

### Cause 2 — not enough training examples for that sentence shape

On top of removing the risky fallback, I added many more example phrases
covering "`<name>` of Grade `<number>`", "Grade `<number>`'s `<name>`", "`<name>`
in Grade `<number>`", etc. — with different names and grades each time —
so Dialogflow actually learns "a name can go here, a grade can go there,"
rather than memorizing one specific pair of values.

### Cause 3 (found while checking the rest of the agent) — text that breaks when a detail is missing

Several other intents (fee details, exam results, cafeteria menu, ID card
issues, portal login problems, scholarships, school policy, volunteering,
and more — **13 intents in total**) had the same underlying flaw in a
different shape: their reply text always mentioned something like
`$fee_type` or `$meal_type`, but that value was marked *optional*. If a
parent asked in a way that didn't clearly state it, the reply would come
out with a blank in it — e.g. *"The for Grade 5 is charged per term."*
I made those slots required (with a natural follow-up question) so the
bot always asks rather than ever showing a broken sentence.

Two of those slots (`payment_status` in fee payments, `weather_status` in
the school-closure intent) were a design mix-up in the original template —
they're *outputs* the bot is supposed to report (Paid/Pending, Open/
Closed), not something a parent would ever say themselves. Those can never
be filled from what a user types, so I removed them as user-facing slots
and put a clear placeholder value in the reply text instead.

### Cause 4 — a webhook pointed at a server that doesn't exist

`agent.json` had every "live data" intent (attendance, fees, exam results,
etc.) pointed at `https://your-deployed-webhook-url.onrender.com/webhook`
— a placeholder that was never actually built or deployed anywhere in this
project. If left as-is, every one of those questions would fail outright
the moment Dialogflow tried to call it — which would be a much worse
failure to hit live in front of a grader than a wrong answer. I turned
webhook calls off entirely, so **every reply now comes from the
(fixed) built-in text responses** — no external dependency that can go
down mid-demo.

## Everything that was fixed, in one list

- Removed the silent "reuse old grade/child from earlier in the chat"
  behavior from 18 intents (this was the exact bug you reported).
- Added ~20 new, properly-annotated training examples covering different
  word orders for "child + grade" and "child + exam" questions, so the
  bot correctly understands phrasing it wasn't shown before.
- Fixed the one broken training example that had a double space in it.
- Found and fixed 13 more intents that could show a broken sentence
  (missing word / blank) when an optional detail wasn't mentioned — made
  the essential slot required with a natural follow-up question instead.
- Removed two nonsensical "slots" (`payment_status`, `weather_status`)
  that a user could never actually say, and replaced them with fixed
  status text.
- Made `ChangeChildIntent`'s reply honest — it used to promise "I'll
  remember this for the rest of the conversation," which is exactly the
  promise that was causing bugs. It now just asks you to restate the
  detail, which is what it actually does.
- Disabled the dead placeholder webhook so nothing can fail from an
  unreachable server during your demo.

## Second pass — a full sweep for anything else broken

You asked if I'd caught everything, so I ran a systematic check across the
whole agent (not just the intents involved in your original bug report) for
several other classes of problem. Found and fixed:

- **46 quick-reply buttons ("chips") that didn't reliably lead anywhere.**
  Tapping a button like "Check Attendance" or "Talk to Principal" sends
  that exact text back as if you'd typed it — but none of those 46 phrases
  existed anywhere in the training data, so tapping them was a coin flip
  between working and hitting the fallback ("sorry, I didn't understand
  that"). I mapped every single chip in the agent to its correct intent as
  a recognized phrase — including annotating the staff-contact ones (e.g.
  "Contact Principal") so tapping them fills in the right slot directly
  instead of asking a redundant follow-up question.
- **4 duplicate training phrases** sitting twice in the same intent
  (harmless, but sloppy — cleaned up).
- Checked for: entities referenced by intents that don't actually exist,
  entity files missing their value lists, duplicate intent names/IDs, the
  same phrase claimed by two different intents (which confuses the
  classifier), and required parameters with no follow-up question defined.
  None of those were present — the agent was clean on all of those fronts.

## What I'd suggest before you submit

1. **Re-import and test the same query that broke it**: "How many days
   was Adrian of grade 11 present this month" — it should now correctly
   say Grade 11, not fall back to anything old.
2. Test a few more mixed-order phrasings for your demo script (e.g.
   "What's the Maths homework for Kabir in Grade 6") to show the grader
   it generalizes, not just memorizes.
3. If your rubric expects live/dynamic data (not just template text with
   "92%" hardcoded everywhere), that's a bigger, separate step — building
   an actual backend/webhook — happy to help with that next if it's in
   scope for your project.
